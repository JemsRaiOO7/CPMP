function AuthPageWrapper({children}){
 return <div className="auth-page"> {children} </div>
}

export default AuthPageWrapper